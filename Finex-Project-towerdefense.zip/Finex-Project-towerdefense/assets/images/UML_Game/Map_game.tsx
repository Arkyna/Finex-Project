<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Tileset" tilewidth="64" tileheight="64" tilecount="256" columns="16">
 <image source="D:/Download/IDM/Compressed/Foozle_2DT0012_Spire_Tileset_1/Tileset/PNGs/Grass Tileset.png" width="1024" height="1024"/>
</tileset>
