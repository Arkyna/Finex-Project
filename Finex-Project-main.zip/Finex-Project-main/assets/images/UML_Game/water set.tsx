<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="water set" tilewidth="64" tileheight="64" tilecount="490" columns="70">
 <image source="D:/Download/IDM/Compressed/Foozle_2DT0012_Spire_Tileset_1/Tileset/PNGs/Animated water tiles.png" width="4480" height="448"/>
</tileset>
