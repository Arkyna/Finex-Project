<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="water_tile" tilewidth="64" tileheight="64" tilecount="490" columns="70">
 <image source="water_tile.png" width="4480" height="448"/>
</tileset>
